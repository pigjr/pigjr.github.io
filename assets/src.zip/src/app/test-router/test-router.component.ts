import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-test-router',
  templateUrl: './test-router.component.html',
  styleUrls: ['./test-router.component.css']
})
export class TestRouterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
