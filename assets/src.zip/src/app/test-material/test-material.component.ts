import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-test-material',
  templateUrl: './test-material.component.html',
  styleUrls: ['./test-material.component.css']
})
export class TestMaterialComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
