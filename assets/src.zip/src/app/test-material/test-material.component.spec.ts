import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TestMaterialComponent } from './test-material.component';

import { APP_BASE_HREF } from '@angular/common';

import { AppSubComponents, ExternalModules } from '../manifest';

describe('TestMaterialComponent', () => {
  let component: TestMaterialComponent;
  let fixture: ComponentFixture<TestMaterialComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ...AppSubComponents ],
      imports: [
        ...ExternalModules
      ],
      providers: [{provide: APP_BASE_HREF, useValue : '/' }]
      
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TestMaterialComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
