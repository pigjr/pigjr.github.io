// Additional Modules
import { TestRouterComponent } from './test-router/test-router.component';
import { TestMaterialComponent } from './test-material/test-material.component';

// Init Step 3
import { RouterModule, Routes } from '@angular/router';

const appRoutes: Routes = [
  { path: 'test-router', component: TestRouterComponent },
  { path: 'hero/:id',      component: TestRouterComponent },
  {
    path: 'test-material',
    component: TestMaterialComponent,
    data: { title: 'Heroes List' }
  },
  { path: '',
    redirectTo: '/',
    pathMatch: 'full'
  },
  { path: '**', component: TestMaterialComponent }
];

// Init Step 4
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {MdButtonModule, MdCheckboxModule} from '@angular/material';
import 'hammerjs';

export const AppSubComponents = [
  TestRouterComponent,
  TestMaterialComponent
]

export const ExternalModules = [
  // Init Step 3
  RouterModule.forRoot(appRoutes),
  // Init Step 4
  BrowserAnimationsModule,
  MdButtonModule,
  MdCheckboxModule
]
